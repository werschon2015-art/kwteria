#!/usr/bin/env bash
# Einrichtung des KWteria-Servers (Ubuntu 24.04). Aufruf: bash setup.sh deine-domain.de
set -euo pipefail

DOMAIN="${1:-}"
if [ -z "$DOMAIN" ]; then
  echo "Aufruf: bash setup.sh deine-domain.de"
  exit 1
fi
if [ "$(id -u)" != "0" ]; then
  echo "Bitte als root ausführen."
  exit 1
fi

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=/opt/kwteria

echo "==> Pakete installieren"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y docker.io docker-compose-v2 ufw unattended-upgrades sqlite3 curl openssl
systemctl enable --now docker

echo "==> Firewall einrichten"
ufw allow OpenSSH
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 443/udp
ufw --force enable

echo "==> Dateien nach $TARGET kopieren"
mkdir -p "$TARGET/data" "$TARGET/backups"
if [ "$SRC" != "$TARGET" ]; then
  cp -r "$SRC/app" "$SRC/docker-compose.yml" "$SRC/Caddyfile" "$SRC/backup.sh" "$TARGET/"
fi
chmod +x "$TARGET/backup.sh"
cd "$TARGET"

if [ ! -f .env ]; then
  ADMIN_PW="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-14)"
  SECRET="$(openssl rand -hex 32)"
  cat > .env <<EOF
DOMAIN=$DOMAIN
BASE_URL=https://$DOMAIN
ADMIN_PASSWORD=$ADMIN_PW
SECRET_KEY=$SECRET
COOKIE_SECURE=1
EOF
  chmod 600 .env
  NEW_PW="$ADMIN_PW"
else
  sed -i "s|^DOMAIN=.*|DOMAIN=$DOMAIN|; s|^BASE_URL=.*|BASE_URL=https://$DOMAIN|" .env
  NEW_PW=""
fi
chown -R 10001:10001 data

echo "==> Prüfen, ob die Domain auf diesen Server zeigt"
MYIP="$(curl -4 -s --max-time 10 https://ifconfig.me || true)"
DOMIP="$(getent ahostsv4 "$DOMAIN" | awk '{print $1; exit}' || true)"
if [ -n "$MYIP" ] && [ "$MYIP" != "$DOMIP" ]; then
  echo "WARNUNG: $DOMAIN zeigt auf '${DOMIP:-nichts}', dieser Server hat aber $MYIP."
  echo "Ohne passenden DNS-Eintrag bekommt die Seite kein HTTPS-Zertifikat."
fi

echo "==> Anwendung starten"
docker compose up -d --build

echo "==> Tägliche Sicherung einrichten"
echo "15 3 * * * root /opt/kwteria/backup.sh >> /var/log/kwteria-backup.log 2>&1" > /etc/cron.d/kwteria-backup
chmod 644 /etc/cron.d/kwteria-backup

echo
echo "Fertig. Die Seiten laufen unter:"
echo "  Gäste (QR-Code):   https://$DOMAIN/"
echo "  Tablet-Station:    https://$DOMAIN/station"
echo "  Verwaltung:        https://$DOMAIN/admin"
if [ -n "$NEW_PW" ]; then
  echo
  echo "Passwort für die Verwaltung: $NEW_PW"
  echo "Bitte notieren. Es steht auch in $TARGET/.env"
fi
