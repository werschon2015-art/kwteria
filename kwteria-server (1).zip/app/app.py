"""KWteria Essensbewertung: anonyme Bewertung per QR-Code oder Tablet-Station."""
import csv
import datetime as dt
import hashlib
import hmac
import io
import json
import os
import secrets
import sqlite3
import time
from collections import defaultdict, deque
from functools import wraps
from zoneinfo import ZoneInfo

from flask import (Flask, Response, abort, g, jsonify, redirect,
                   render_template, request, session, url_for)
from markupsafe import Markup

try:
    import segno
except ImportError:  # QR-Code ist nur für den Aushang nötig
    segno = None

TZ = ZoneInfo("Europe/Berlin")
DB_PATH = os.environ.get("DB_PATH", "/data/bewertung.db")
BASE_URL = os.environ.get("BASE_URL", "").rstrip("/")
ADMIN_PASSWORD = os.environ["ADMIN_PASSWORD"]

MENUS = [("fleisch", "Menü Fleisch"), ("veg", "Menü Vegetarisch"),
         ("suppe", "Tagessuppe"), ("fruehstueck", "Warmes Frühstück")]
MENU_NAMES = dict(MENUS)
LEVELS = ["Top", "Gut", "Naja", "Schlecht"]
MONTHS = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli",
          "August", "September", "Oktober", "November", "Dezember"]
ORDER_MENUS = ["fleisch", "veg"]
CUTOFF = os.environ.get("VORBESTELLEN_BIS", "14:00")
CODE_CHARS = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
WEEKDAYS = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag",
            "Samstag", "Sonntag"]

app = Flask(__name__)
app.secret_key = os.environ["SECRET_KEY"]
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1") == "1",
    PERMANENT_SESSION_LIFETIME=dt.timedelta(hours=12),
    MAX_CONTENT_LENGTH=64 * 1024,
)


# ---------- Datenbank ----------
def connect():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    return con


def db():
    if "db" not in g:
        g.db = connect()
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    con = g.pop("db", None)
    if con is not None:
        con.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    con = connect()
    con.executescript("""
        CREATE TABLE IF NOT EXISTS plan(
            day TEXT NOT NULL, menu TEXT NOT NULL,
            main TEXT NOT NULL, rest TEXT NOT NULL DEFAULT '',
            PRIMARY KEY(day, menu));
        CREATE TABLE IF NOT EXISTS votes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            day TEXT NOT NULL, menu TEXT NOT NULL, level INTEGER NOT NULL,
            dish TEXT NOT NULL, ts TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS votes_day ON votes(day);
        CREATE TABLE IF NOT EXISTS preorders(
            code TEXT NOT NULL, day TEXT NOT NULL, menu TEXT NOT NULL,
            name TEXT NOT NULL DEFAULT '', ts TEXT NOT NULL,
            PRIMARY KEY(code, day));
        CREATE INDEX IF NOT EXISTS preorders_day ON preorders(day);
    """)
    old = (dt.date.today() - dt.timedelta(days=60)).isoformat()
    con.execute("DELETE FROM preorders WHERE day < ?", (old,))
    if con.execute("SELECT COUNT(*) FROM plan").fetchone()[0] == 0:
        path = os.path.join(os.path.dirname(__file__), "seed.json")
        if os.path.exists(path):
            with open(path, encoding="utf-8") as fh:
                seed = json.load(fh)
            for week_start, week in seed.get("weeks", {}).items():
                start = dt.date.fromisoformat(week_start)
                for idx, day in week.items():
                    iso = (start + dt.timedelta(days=int(idx))).isoformat()
                    for menu, item in day.items():
                        if menu not in MENU_NAMES or not item.get("main"):
                            continue
                        rest = ", ".join((item.get("sides") or []) + (item.get("gem") or [])
                                         + (item.get("sauce") or []))
                        con.execute("INSERT OR IGNORE INTO plan(day,menu,main,rest) VALUES(?,?,?,?)",
                                    (iso, menu, item["main"][0], rest))
    con.commit()
    con.close()


# ---------- Hilfen ----------
def today():
    return dt.datetime.now(TZ).date().isoformat()


def long_date(iso):
    d = dt.date.fromisoformat(iso)
    return f"{WEEKDAYS[d.weekday()]}, {d.day}. {MONTHS[d.month - 1]}"


def menus_for(day):
    rows = {r["menu"]: r for r in db().execute("SELECT menu, main, rest FROM plan WHERE day=?", (day,))}
    return [{"id": mid, "name": name, "main": rows[mid]["main"], "rest": rows[mid]["rest"]}
            for mid, name in MENUS if mid in rows]


def client_key():
    forwarded = request.headers.get("X-Forwarded-For", "")
    ip = forwarded.split(",")[0].strip() or request.remote_addr or "?"
    return hashlib.sha256((app.secret_key + ip).encode()).hexdigest()[:16]


_hits = defaultdict(deque)


def allow(bucket, limit, window):
    """Einfache Begrenzung im Speicher. Es werden keine IP-Adressen gespeichert."""
    key = (bucket, client_key())
    now = time.monotonic()
    q = _hits[key]
    while q and now - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        return False
    q.append(now)
    if len(_hits) > 5000:
        for k in [k for k, v in _hits.items() if not v or now - v[-1] > window]:
            _hits.pop(k, None)
    return True


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(24)
    return session["csrf"]


app.jinja_env.globals.update(csrf_token=csrf_token, long_date=long_date, LEVELS=LEVELS,
                             MENUS=MENUS, MENU_NAMES=MENU_NAMES)


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("login", weiter=request.path))
        if request.method == "POST" and not hmac.compare_digest(
                request.form.get("csrf", ""), session.get("csrf", "")):
            abort(400)
        return view(*args, **kwargs)
    return wrapped


@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'")
    if request.path.startswith(("/admin", "/api")) or request.path in ("/", "/station"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


# ---------- Gäste ----------
@app.get("/")
def rate():
    day = today()
    return render_template("rate.html", mode="phone", day=day, menus=menus_for(day))


@app.get("/station")
def station():
    day = today()
    return render_template("rate.html", mode="station", day=day, menus=menus_for(day))


@app.post("/api/vote")
def api_vote():
    if not allow("vote", 40, 60):
        return jsonify(error="Zu viele Anfragen. Bitte kurz warten."), 429
    data = request.get_json(silent=True) or {}
    menu, level = data.get("menu"), data.get("level")
    if menu not in MENU_NAMES or isinstance(level, bool) or not isinstance(level, int) or not 0 <= level <= 3:
        abort(400)
    day = today()
    row = db().execute("SELECT main FROM plan WHERE day=? AND menu=?", (day, menu)).fetchone()
    if not row:
        return jsonify(error="Dieses Gericht gibt es heute nicht."), 404
    db().execute("INSERT INTO votes(day,menu,level,dish,ts) VALUES(?,?,?,?,?)",
                 (day, menu, level, row["main"], dt.datetime.now(TZ).isoformat(timespec="seconds")))
    db().commit()
    return jsonify(ok=True)


@app.get("/healthz")
def healthz():
    db().execute("SELECT 1")
    return "ok"


# ---------- Vorbestellung ----------
def cutoff_for(day):
    """Bestellschluss: am vorherigen Werktag um CUTOFF Uhr."""
    d = dt.date.fromisoformat(day) - dt.timedelta(days=1)
    while d.weekday() >= 5:
        d -= dt.timedelta(days=1)
    try:
        h, m = (int(x) for x in CUTOFF.split(":"))
    except ValueError:
        h, m = 14, 0
    return dt.datetime(d.year, d.month, d.day, h, m, tzinfo=TZ)


def short_cutoff(when):
    return f"{WEEKDAYS[when.weekday()]} {when.strftime('%H:%M')} Uhr"


def order_days(span=13):
    """Tage ab morgen mit Mittagessen im Plan."""
    start = dt.date.fromisoformat(today()) + dt.timedelta(days=1)
    end = start + dt.timedelta(days=span)
    rows = db().execute(
        "SELECT day, menu, main, rest FROM plan WHERE day BETWEEN ? AND ? AND menu IN ('fleisch','veg') "
        "ORDER BY day", (start.isoformat(), end.isoformat())).fetchall()
    days = {}
    for r in rows:
        days.setdefault(r["day"], {})[r["menu"]] = {"main": r["main"], "rest": r["rest"]}
    now = dt.datetime.now(TZ)
    out = []
    for iso in sorted(days):
        cut = cutoff_for(iso)
        out.append({"iso": iso, "label": long_date(iso), "menus": days[iso],
                    "open": now < cut, "cutoff": short_cutoff(cut)})
    return out


def current_code():
    code = (request.cookies.get("vb") or "").upper()
    return code if len(code) == 6 and all(c in CODE_CHARS for c in code) else ""


def new_code():
    while True:
        code = "".join(secrets.choice(CODE_CHARS) for _ in range(6))
        if not db().execute("SELECT 1 FROM preorders WHERE code=? LIMIT 1", (code,)).fetchone():
            return code


@app.route("/vorbestellen", methods=["GET", "POST"])
def vorbestellen():
    code = current_code()
    msg, err = "", ""
    days = order_days()
    if request.method == "POST":
        action = request.form.get("aktion", "")
        if not allow("order", 30, 60):
            err = "Zu viele Anfragen. Bitte kurz warten."
        elif action == "code":
            wanted = request.form.get("code", "").strip().upper().replace(" ", "").replace("-", "")
            if len(wanted) == 6 and all(c in CODE_CHARS for c in wanted) and db().execute(
                    "SELECT 1 FROM preorders WHERE code=? LIMIT 1", (wanted,)).fetchone():
                code, msg = wanted, "Code übernommen. Hier siehst du deine Bestellung."
            else:
                err = "Diesen Code gibt es nicht. Bitte prüfen."
        elif action == "abmelden":
            code, msg = "", "Dieses Gerät ist abgemeldet. Deine Bestellung bleibt gespeichert."
        elif action == "speichern":
            name = request.form.get("name", "").strip()[:40]
            choices = {d["iso"]: request.form.get("tag_" + d["iso"], "") for d in days if d["open"]}
            if any(v in ORDER_MENUS for v in choices.values()) and not code:
                code = new_code()
            if code:
                con = db()
                stamp = dt.datetime.now(TZ).isoformat(timespec="seconds")
                for d in days:
                    if not d["open"]:
                        continue
                    v = choices.get(d["iso"], "")
                    if v in ORDER_MENUS and v in d["menus"]:
                        con.execute("INSERT INTO preorders(code,day,menu,name,ts) VALUES(?,?,?,?,?) "
                                    "ON CONFLICT(code,day) DO UPDATE SET menu=excluded.menu, "
                                    "name=excluded.name, ts=excluded.ts", (code, d["iso"], v, name, stamp))
                    else:
                        con.execute("DELETE FROM preorders WHERE code=? AND day=?", (code, d["iso"]))
                con.execute("UPDATE preorders SET name=? WHERE code=? AND day>=?", (name, code, today()))
                con.commit()
                msg = "Gespeichert. Du kannst bis zum Bestellschluss jederzeit ändern."
            else:
                msg = "Du hast kein Essen ausgewählt."
    mine, name = {}, ""
    if code:
        for r in db().execute("SELECT day, menu, name FROM preorders WHERE code=? AND day>?", (code, today())):
            mine[r["day"]] = r["menu"]
            name = name or r["name"]
    resp = app.make_response(render_template("vorbestellen.html", days=days, mine=mine, code=code,
                                             name=name, msg=msg, err=err, cutoff=CUTOFF))
    if code:
        resp.set_cookie("vb", code, max_age=180 * 86400, httponly=True, samesite="Lax",
                        secure=app.config["SESSION_COOKIE_SECURE"])
    elif request.cookies.get("vb"):
        resp.delete_cookie("vb")
    resp.headers["Cache-Control"] = "no-store"
    return resp


# ---------- Verwaltung ----------
@app.route("/admin/login", methods=["GET", "POST"])
def login():
    error = ""
    if request.method == "POST":
        if not allow("login", 8, 600):
            error = "Zu viele Versuche. Bitte in ein paar Minuten noch einmal."
        elif hmac.compare_digest(request.form.get("passwort", ""), ADMIN_PASSWORD):
            session.clear()
            session.permanent = True
            session["admin"] = True
            target = request.args.get("weiter", "")
            return redirect(target if target.startswith("/admin") else url_for("auswertung"))
        else:
            time.sleep(0.6)
            error = "Falsches Passwort."
    return render_template("login.html", error=error)


@app.get("/admin/logout")
def logout():
    session.clear()
    return redirect(url_for("rate"))


@app.get("/admin")
def admin_home():
    return redirect(url_for("auswertung"))


def period():
    value = request.args.get("monat") or today()[:7]
    if value == "alle":
        return "alle", "", ()
    try:
        y, m = int(value[:4]), int(value[5:7])
        dt.date(y, m, 1)
    except (ValueError, IndexError):
        y, m = dt.date.fromisoformat(today()).year, dt.date.fromisoformat(today()).month
    value = f"{y}-{m:02d}"
    return value, "WHERE day LIKE ?", (value + "-%",)


def collect(where, params):
    rows = db().execute(
        f"SELECT day, menu, dish, level, COUNT(*) n FROM votes {where} GROUP BY day, menu, dish, level",
        params).fetchall()
    days, dishes = {}, {}
    for r in rows:
        entry = days.setdefault(r["day"], {}).setdefault(
            r["menu"], {"dish": r["dish"], "a": [0, 0, 0, 0]})
        entry["a"][r["level"]] += r["n"]
        d = dishes.setdefault(r["dish"].strip().lower(),
                              {"name": r["dish"], "menu": MENU_NAMES.get(r["menu"], ""), "a": [0, 0, 0, 0]})
        d["a"][r["level"]] += r["n"]

    def finish(a):
        n = sum(a)
        return {"a": a, "n": n, "sat": round((a[0] + a[1]) * 100 / n) if n else 0,
                "w": [round(x * 100 / n, 2) if n else 0 for x in a]}

    day_list = []
    for iso in sorted(days, reverse=True):
        items = []
        for mid, name in MENUS:
            if mid in days[iso]:
                e = days[iso][mid]
                items.append({"menu": name, "dish": e["dish"], **finish(e["a"])})
        day_list.append({"iso": iso, "label": long_date(iso), "rows": items})
    rank = [{"name": d["name"], "menu": d["menu"], **finish(d["a"])} for d in dishes.values()]
    rank.sort(key=lambda x: (-x["sat"], -x["n"]))
    total = sum(x["n"] for x in rank)
    sat = sum(x["a"][0] + x["a"][1] for x in rank)
    return day_list, rank, total, round(sat * 100 / total) if total else 0


def month_nav(value):
    if value == "alle":
        return None, None
    y, m = int(value[:4]), int(value[5:7])
    prev = (y, m - 1) if m > 1 else (y - 1, 12)
    nxt = (y, m + 1) if m < 12 else (y + 1, 1)
    return f"{prev[0]}-{prev[1]:02d}", f"{nxt[0]}-{nxt[1]:02d}"


@app.get("/admin/auswertung")
@admin_required
def auswertung():
    value, where, params = period()
    day_list, rank, total, sat = collect(where, params)
    prev, nxt = month_nav(value)
    label = "Gesamt" if value == "alle" else f"{MONTHS[int(value[5:7]) - 1]} {value[:4]}"
    return render_template("auswertung.html", tab="eval", value=value, label=label, prev=prev,
                           nxt=nxt, days=day_list, rank=rank, total=total, sat=sat)


@app.get("/admin/export.csv")
@admin_required
def export_csv():
    value, where, params = period()
    day_list, _rank, _total, _sat = collect(where, params)
    out = io.StringIO()
    w = csv.writer(out, delimiter=";")
    w.writerow(["Datum", "Menü", "Gericht", *LEVELS, "Summe", "Zufrieden %"])
    for d in sorted(day_list, key=lambda x: x["iso"]):
        for it in d["rows"]:
            w.writerow([d["iso"], it["menu"], it["dish"], *it["a"], it["n"], it["sat"]])
    name = f"bewertungen-{value}.csv"
    return Response("﻿" + out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@app.route("/admin/plan", methods=["GET", "POST"])
@admin_required
def plan():
    day = request.values.get("tag") or today()
    try:
        d = dt.date.fromisoformat(day)
    except ValueError:
        d = dt.date.fromisoformat(today())
    day = d.isoformat()
    msg = ""
    if request.method == "POST":
        con = db()
        for mid, _name in MENUS:
            main = request.form.get(f"main_{mid}", "").strip()[:120]
            rest = request.form.get(f"rest_{mid}", "").strip()[:200]
            if main:
                con.execute("INSERT INTO plan(day,menu,main,rest) VALUES(?,?,?,?) "
                            "ON CONFLICT(day,menu) DO UPDATE SET main=excluded.main, rest=excluded.rest",
                            (day, mid, main, rest))
            else:
                con.execute("DELETE FROM plan WHERE day=? AND menu=?", (day, mid))
        con.commit()
        msg = "Gespeichert."
    current = {m["id"]: m for m in menus_for(day)}
    voted = db().execute("SELECT COUNT(*) FROM votes WHERE day=?", (day,)).fetchone()[0]
    return render_template("plan.html", tab="plan", day=day, current=current, voted=voted, msg=msg,
                           prev=(d - dt.timedelta(days=1)).isoformat(),
                           nxt=(d + dt.timedelta(days=1)).isoformat())


@app.get("/admin/vorbestellungen")
@admin_required
def vorbestellungen():
    start = dt.date.fromisoformat(today())
    end = start + dt.timedelta(days=13)
    plan_rows = db().execute(
        "SELECT day, menu, main FROM plan WHERE day BETWEEN ? AND ? AND menu IN ('fleisch','veg')",
        (start.isoformat(), end.isoformat())).fetchall()
    orders = db().execute(
        "SELECT day, menu, name, code FROM preorders WHERE day BETWEEN ? AND ? ORDER BY name, code",
        (start.isoformat(), end.isoformat())).fetchall()
    days = {}
    for r in plan_rows:
        days.setdefault(r["day"], {"menus": {}, "people": {m: [] for m in ORDER_MENUS}})["menus"][r["menu"]] = r["main"]
    for o in orders:
        d = days.setdefault(o["day"], {"menus": {}, "people": {m: [] for m in ORDER_MENUS}})
        d["people"].setdefault(o["menu"], []).append(o["name"] or ("Code " + o["code"]))
    now = dt.datetime.now(TZ)
    out = []
    for iso in sorted(days):
        d = days[iso]
        cut = cutoff_for(iso)
        out.append({"iso": iso, "label": long_date(iso), "menus": d["menus"], "people": d["people"],
                    "total": sum(len(v) for v in d["people"].values()),
                    "closed": now >= cut, "cutoff": short_cutoff(cut)})
    return render_template("vorbestellungen.html", tab="orders", days=out, today_iso=today())


@app.get("/admin/aushang")
@admin_required
def aushang():
    art = "vorbestellen" if request.args.get("art") == "vorbestellen" else "bewertung"
    url = (BASE_URL or request.url_root.rstrip("/")) + ("/vorbestellen" if art == "vorbestellen" else "/")
    svg = ""
    if segno is not None:
        svg = Markup(segno.make(url, error="m").svg_inline(scale=10, border=2, dark="#000000",
                                                           light="#ffffff"))
    return render_template("aushang.html", tab="poster", url=url, svg=svg, art=art, cutoff=CUTOFF)


if __name__ != "__main__":
    init_db()
