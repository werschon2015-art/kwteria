#!/usr/bin/env bash
# Holt die neueste Version von GitHub und spielt sie ein. Daten und Passwort bleiben erhalten.
# Aufruf: bash /root/kw/update.sh
set -euo pipefail
REPO_URL="${REPO_URL:-https://github.com/werschon2015-art/kwteria/raw/main/kwteria-server.zip}"
DOMAIN="$(grep '^DOMAIN=' /opt/kwteria/.env | cut -d= -f2)"
cd /root
curl -fsSL -o k.zip "$REPO_URL"
rm -rf /root/kw
unzip -oq k.zip -d /root/kw
cd /root/kw
bash setup.sh "$DOMAIN"
