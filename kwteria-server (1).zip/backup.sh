#!/usr/bin/env bash
# Tägliche Sicherung der Bewertungsdatenbank, die letzten 30 Tage bleiben erhalten.
set -euo pipefail
cd /opt/kwteria
mkdir -p backups
sqlite3 data/bewertung.db ".backup 'backups/bewertung-$(date +%F).db'"
find backups -name 'bewertung-*.db' -mtime +30 -delete
